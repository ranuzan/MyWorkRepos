﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B_8
{
    public partial class Show_Meeting : Form
    {
        public Show_Meeting()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
            main m = new B_8.main();
            m.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Close();
            login log = new B_8.login();
            log.Show();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            this.Close();
            Schedule s = new Schedule();
            s.Show();
        }
    }
}

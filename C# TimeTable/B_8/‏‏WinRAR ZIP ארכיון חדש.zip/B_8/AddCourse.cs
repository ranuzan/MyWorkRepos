﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace B_8
{
    public partial class AddCourse : Form
    {
        DataBase db = new DataBase();
        public bool IsUnitTest = false;
        public AddCourse()
        {
            InitializeComponent();
            IsUnitTest = true;

        }
        
        private void AddCourse_Load(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void textBox6_TextChanged(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }

        private void confirm_Click(object sender, EventArgs e)
        {

            string name = textBox1.Text;
            string id = textBox2.Text;
            string credits = textBox3.Text;
            string lectureH = textBox4.Text;
            string practiceH = textBox5.Text;
            string receiptH = textBox6.Text;
            string semster = comboBox2.Text;
            string Year = comboBox4.Text;
            string department = comboBox3.Text;

            try
            {
                if (name != null && id != null && credits != null && lectureH != null && practiceH != null && receiptH != null && Year != null && semster != null && department != null)
                    if (Int32.Parse(id) > 0 & Int32.Parse(lectureH) > 0 & Int32.Parse(practiceH) > 0 & Int32.Parse(receiptH) > 0)// & Int32.Parse(Year) > 0)
                        db.InsertCourse(name, id, credits, lectureH, practiceH, receiptH, semster, Year, department);

                Hide();
                main ss = new main();
                ss.Show();
            }
            catch(Exception exp)
            {
                MessageBox.Show("Could not insert");

            }
            finally
            {
                if (db.isconnected == true)
                    db.CloseConnection();
            }
        }

        private void EXIT_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label8_Click(object sender, EventArgs e) { }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e) { }
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e) { }
        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e) { }
        private void label9_Click(object sender, EventArgs e) { }

        private void Home_Click(object sender, EventArgs e)
        {
            this.Hide();
            main ss = new main();
            ss.Show();
        }

        private void logOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            login ss = new login();
            ss.Show();
        }
    }
}

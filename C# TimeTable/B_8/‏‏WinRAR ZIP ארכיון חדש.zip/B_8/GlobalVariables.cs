﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_8
{
    public static class GlobalVariables
    {
        public static string User_Name;
        public static string Full_Name;
        public static string User_Email;
        public static string User_ID;
        public static string User_Permission;
        public static string User_Department;
        public static string Semester;
        public static DateTime maxDate;
        public static DateTime minDate;
    }
}

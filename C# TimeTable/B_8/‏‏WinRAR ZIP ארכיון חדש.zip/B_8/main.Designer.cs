﻿namespace B_8
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Add_course_to_schedules = new System.Windows.Forms.Button();
            this.Constraints = new System.Windows.Forms.Button();
            this.Delete_course = new System.Windows.Forms.Button();
            this.Add_User = new System.Windows.Forms.Button();
            this.Show_course_by_semester = new System.Windows.Forms.Button();
            this.Schedule = new System.Windows.Forms.Button();
            this.Search_Course = new System.Windows.Forms.Button();
            this.Show_students = new System.Windows.Forms.Button();
            this.Display_courses = new System.Windows.Forms.Button();
            this.Add_course_to_system = new System.Windows.Forms.Button();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.BackgroundImage = global::B_8.Properties.Resources.blue_surface_with_creases_1160_191;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.menuStrip1.Location = new System.Drawing.Point(0, 425);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(975, 24);
            this.menuStrip1.TabIndex = 59;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(125, 20);
            this.toolStripMenuItem1.Text = "toolStripMenuItem1";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(125, 20);
            this.toolStripMenuItem2.Text = "toolStripMenuItem2";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(125, 20);
            this.toolStripMenuItem3.Text = "toolStripMenuItem3";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(125, 20);
            this.toolStripMenuItem4.Text = "toolStripMenuItem4";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Add_course_to_schedules
            // 
            this.Add_course_to_schedules.BackColor = System.Drawing.Color.Beige;
            this.Add_course_to_schedules.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Add_course_to_schedules.BackgroundImage")));
            this.Add_course_to_schedules.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Add_course_to_schedules.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_course_to_schedules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Add_course_to_schedules.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_course_to_schedules.ForeColor = System.Drawing.Color.White;
            this.Add_course_to_schedules.Image = global::B_8.Properties.Resources.Notebook_Pen_icon5;
            this.Add_course_to_schedules.Location = new System.Drawing.Point(2, 2);
            this.Add_course_to_schedules.Margin = new System.Windows.Forms.Padding(2);
            this.Add_course_to_schedules.Name = "Add_course_to_schedules";
            this.Add_course_to_schedules.Size = new System.Drawing.Size(191, 95);
            this.Add_course_to_schedules.TabIndex = 60;
            this.Add_course_to_schedules.Text = "Show Exams";
            this.Add_course_to_schedules.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Add_course_to_schedules.UseVisualStyleBackColor = false;
            this.Add_course_to_schedules.Click += new System.EventHandler(this.button1_Click);
            // 
            // Constraints
            // 
            this.Constraints.BackColor = System.Drawing.Color.Beige;
            this.Constraints.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Constraints.BackgroundImage")));
            this.Constraints.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Constraints.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Constraints.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Constraints.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Constraints.ForeColor = System.Drawing.Color.White;
            this.Constraints.Image = global::B_8.Properties.Resources._1493309938_add_notes;
            this.Constraints.Location = new System.Drawing.Point(2, 101);
            this.Constraints.Margin = new System.Windows.Forms.Padding(2);
            this.Constraints.Name = "Constraints";
            this.Constraints.Size = new System.Drawing.Size(191, 95);
            this.Constraints.TabIndex = 62;
            this.Constraints.Text = "Constraints";
            this.Constraints.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Constraints.UseVisualStyleBackColor = false;
            this.Constraints.Click += new System.EventHandler(this.button2_Click);
            // 
            // Delete_course
            // 
            this.Delete_course.BackColor = System.Drawing.Color.Beige;
            this.Delete_course.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Delete_course.BackgroundImage")));
            this.Delete_course.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Delete_course.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Delete_course.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Delete_course.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete_course.ForeColor = System.Drawing.Color.White;
            this.Delete_course.Image = global::B_8.Properties.Resources.Folder_Delete_icon__1_;
            this.Delete_course.Location = new System.Drawing.Point(392, 200);
            this.Delete_course.Margin = new System.Windows.Forms.Padding(2);
            this.Delete_course.Name = "Delete_course";
            this.Delete_course.Size = new System.Drawing.Size(191, 95);
            this.Delete_course.TabIndex = 63;
            this.Delete_course.Text = "Delete Course";
            this.Delete_course.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Delete_course.UseVisualStyleBackColor = false;
            this.Delete_course.Click += new System.EventHandler(this.button3_Click);
            // 
            // Add_User
            // 
            this.Add_User.BackColor = System.Drawing.Color.Beige;
            this.Add_User.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Add_User.BackgroundImage")));
            this.Add_User.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Add_User.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_User.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Add_User.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_User.ForeColor = System.Drawing.Color.White;
            this.Add_User.Image = global::B_8.Properties.Resources.user_add_icon;
            this.Add_User.Location = new System.Drawing.Point(587, 101);
            this.Add_User.Margin = new System.Windows.Forms.Padding(2);
            this.Add_User.Name = "Add_User";
            this.Add_User.Size = new System.Drawing.Size(191, 95);
            this.Add_User.TabIndex = 64;
            this.Add_User.Text = "Add User";
            this.Add_User.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Add_User.UseVisualStyleBackColor = false;
            this.Add_User.Click += new System.EventHandler(this.button4_Click);
            // 
            // Show_course_by_semester
            // 
            this.Show_course_by_semester.BackColor = System.Drawing.Color.Beige;
            this.Show_course_by_semester.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Show_course_by_semester.BackgroundImage")));
            this.Show_course_by_semester.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Show_course_by_semester.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Show_course_by_semester.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Show_course_by_semester.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Show_course_by_semester.ForeColor = System.Drawing.Color.White;
            this.Show_course_by_semester.Image = global::B_8.Properties.Resources.My_Documents_icon;
            this.Show_course_by_semester.Location = new System.Drawing.Point(197, 101);
            this.Show_course_by_semester.Margin = new System.Windows.Forms.Padding(2);
            this.Show_course_by_semester.Name = "Show_course_by_semester";
            this.Show_course_by_semester.Size = new System.Drawing.Size(191, 95);
            this.Show_course_by_semester.TabIndex = 66;
            this.Show_course_by_semester.Text = "Show courses by semester";
            this.Show_course_by_semester.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Show_course_by_semester.UseVisualStyleBackColor = false;
            this.Show_course_by_semester.Click += new System.EventHandler(this.button5_Click);
            // 
            // Schedule
            // 
            this.Schedule.BackColor = System.Drawing.Color.Beige;
            this.Schedule.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Schedule.BackgroundImage")));
            this.Schedule.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Schedule.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Schedule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Schedule.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Schedule.ForeColor = System.Drawing.Color.White;
            this.Schedule.Image = global::B_8.Properties.Resources.Mimetype_schedule_icon;
            this.Schedule.Location = new System.Drawing.Point(197, 2);
            this.Schedule.Margin = new System.Windows.Forms.Padding(2);
            this.Schedule.Name = "Schedule";
            this.Schedule.Size = new System.Drawing.Size(191, 95);
            this.Schedule.TabIndex = 68;
            this.Schedule.Text = "Schedule";
            this.Schedule.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Schedule.UseVisualStyleBackColor = false;
            this.Schedule.Click += new System.EventHandler(this.button6_Click);
            // 
            // Search_Course
            // 
            this.Search_Course.BackColor = System.Drawing.Color.Beige;
            this.Search_Course.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Search_Course.BackgroundImage")));
            this.Search_Course.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Search_Course.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Search_Course.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Search_Course.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search_Course.ForeColor = System.Drawing.Color.White;
            this.Search_Course.Image = global::B_8.Properties.Resources.Search_icon1;
            this.Search_Course.Location = new System.Drawing.Point(2, 200);
            this.Search_Course.Margin = new System.Windows.Forms.Padding(2);
            this.Search_Course.Name = "Search_Course";
            this.Search_Course.Size = new System.Drawing.Size(191, 95);
            this.Search_Course.TabIndex = 70;
            this.Search_Course.Text = "Search Course";
            this.Search_Course.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Search_Course.UseVisualStyleBackColor = false;
            this.Search_Course.Click += new System.EventHandler(this.button7_Click);
            // 
            // Show_students
            // 
            this.Show_students.BackColor = System.Drawing.Color.Beige;
            this.Show_students.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Show_students.BackgroundImage")));
            this.Show_students.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Show_students.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Show_students.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Show_students.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Show_students.ForeColor = System.Drawing.Color.White;
            this.Show_students.Image = global::B_8.Properties.Resources.Student_3_icon;
            this.Show_students.Location = new System.Drawing.Point(392, 2);
            this.Show_students.Margin = new System.Windows.Forms.Padding(2);
            this.Show_students.Name = "Show_students";
            this.Show_students.Size = new System.Drawing.Size(191, 95);
            this.Show_students.TabIndex = 72;
            this.Show_students.Text = "Show students ";
            this.Show_students.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Show_students.UseVisualStyleBackColor = false;
            this.Show_students.Click += new System.EventHandler(this.button8_Click);
            // 
            // Display_courses
            // 
            this.Display_courses.BackColor = System.Drawing.Color.Beige;
            this.Display_courses.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Display_courses.BackgroundImage")));
            this.Display_courses.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Display_courses.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Display_courses.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Display_courses.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Display_courses.ForeColor = System.Drawing.Color.White;
            this.Display_courses.Image = global::B_8.Properties.Resources.Books_icon;
            this.Display_courses.Location = new System.Drawing.Point(197, 200);
            this.Display_courses.Margin = new System.Windows.Forms.Padding(2);
            this.Display_courses.Name = "Display_courses";
            this.Display_courses.Size = new System.Drawing.Size(191, 95);
            this.Display_courses.TabIndex = 73;
            this.Display_courses.Text = "Display courses";
            this.Display_courses.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Display_courses.UseVisualStyleBackColor = false;
            this.Display_courses.Click += new System.EventHandler(this.button9_Click);
            // 
            // Add_course_to_system
            // 
            this.Add_course_to_system.BackColor = System.Drawing.Color.Beige;
            this.Add_course_to_system.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Add_course_to_system.BackgroundImage")));
            this.Add_course_to_system.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Add_course_to_system.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_course_to_system.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Add_course_to_system.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_course_to_system.ForeColor = System.Drawing.Color.White;
            this.Add_course_to_system.Image = global::B_8.Properties.Resources.Add_Folder_icon;
            this.Add_course_to_system.Location = new System.Drawing.Point(587, 2);
            this.Add_course_to_system.Margin = new System.Windows.Forms.Padding(2);
            this.Add_course_to_system.Name = "Add_course_to_system";
            this.Add_course_to_system.Size = new System.Drawing.Size(191, 95);
            this.Add_course_to_system.TabIndex = 76;
            this.Add_course_to_system.Text = "Add course to system";
            this.Add_course_to_system.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Add_course_to_system.UseVisualStyleBackColor = false;
            this.Add_course_to_system.Click += new System.EventHandler(this.button10_Click);
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.Color.White;
            this.menuStrip2.BackgroundImage = global::B_8.Properties.Resources.blue_surface_with_creases_1160_191;
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem5,
            this.toolStripMenuItem8});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip2.Size = new System.Drawing.Size(975, 28);
            this.menuStrip2.TabIndex = 77;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem6.Image = global::B_8.Properties.Resources._067861_3d_glossy_blue_orb_icon_alphanumeric_crossing;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(57, 24);
            this.toolStripMenuItem6.Text = "Exit";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem7.Image = global::B_8.Properties.Resources.logout_icooon;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(77, 24);
            this.toolStripMenuItem7.Text = "Logout";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem5.Image = global::B_8.Properties.Resources.Actions_help_about_icon;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(88, 24);
            this.toolStripMenuItem5.Text = "About Us";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click_1);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem8.Image = global::B_8.Properties.Resources.email_info_icon;
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(60, 24);
            this.toolStripMenuItem8.Text = "Info";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::B_8.Properties.Resources.university_icon;
            this.pictureBox1.Location = new System.Drawing.Point(782, 200);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(191, 95);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 78;
            this.pictureBox1.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Beige;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = global::B_8.Properties.Resources.schedule_icon;
            this.button2.Location = new System.Drawing.Point(392, 101);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(191, 95);
            this.button2.TabIndex = 80;
            this.button2.Text = "Semester Schedule";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.button1, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Add_course_to_schedules, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button2, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.Delete_course, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.Display_courses, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.Schedule, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.Search_Course, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Show_students, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.Add_User, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.Add_course_to_system, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.Constraints, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Show_course_by_semester, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 4, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 28);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(975, 397);
            this.tableLayoutPanel1.TabIndex = 81;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Beige;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = global::B_8.Properties.Resources.images2;
            this.button1.Location = new System.Drawing.Point(2, 299);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(191, 96);
            this.button1.TabIndex = 82;
            this.button1.Text = "Classroom Table";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(782, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(191, 95);
            this.panel1.TabIndex = 81;
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(975, 449);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "main";
            this.Load += new System.EventHandler(this.main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.Button Add_course_to_schedules;
        private System.Windows.Forms.Button Constraints;
        private System.Windows.Forms.Button Delete_course;
        private System.Windows.Forms.Button Add_User;
        private System.Windows.Forms.Button Show_course_by_semester;
        private System.Windows.Forms.Button Schedule;
        private System.Windows.Forms.Button Search_Course;
        private System.Windows.Forms.Button Show_students;
        private System.Windows.Forms.Button Display_courses;
        private System.Windows.Forms.Button Add_course_to_system;
        public System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        public System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.Button button1;
    }
}
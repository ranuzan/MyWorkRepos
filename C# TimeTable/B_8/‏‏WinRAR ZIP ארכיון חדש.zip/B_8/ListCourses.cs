﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace B_8
{
    public partial class ListCourses : Form
    {
        DataBase db = new DataBase();
        public bool IsUnitTest = false;


        public ListCourses()
        {
            InitializeComponent();
            combo_box.Visible = false;
            listView1.Visible = false;
            IsUnitTest = true;


        }

        private void Year_C_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string comboText = combo_box.Text;
                string Type = Yaer_Department.Text;
                if (comboText != null)
                {
                    SqlDataReader reader = db.Select("*", "Courses");
                    listView1.Items.Clear();
                    listView1.Visible = true;
                    while (reader.Read() == true)
                    {
                        if (Type == "Year")
                        {
                            if (reader["Year"].ToString().Trim() == combo_box.Text)
                            {
                                listView1.Items.Add(init(reader));
                            }
                        }
                        if (Type == "Department")
                        {
                            if (reader["Department"].ToString().Trim() == combo_box.Text)
                            {
                                listView1.Items.Add(init(reader));
                            }
                        }
                    }
                    reader.Close();
                }
            }
            catch(Exception exp)
            {
                MessageBox.Show("Could not connect to sql");
            }
            finally
            {
                if (db.isconnected == true)
                    db.CloseConnection();
            }

        }

        private void Department_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public ListViewItem init(SqlDataReader reader)
        {
            ListViewItem item = new ListViewItem(reader["Name"].ToString().Trim());
            item.SubItems.Add(reader["ID"].ToString().Trim());
            item.SubItems.Add(reader["Credits"].ToString().Trim());
            item.SubItems.Add(reader["LectureHour"].ToString().Trim());
            item.SubItems.Add(reader["PracticeHour"].ToString().Trim());
            item.SubItems.Add(reader["ReceptionHour"].ToString().Trim());
            item.SubItems.Add(reader["Semester"].ToString().Trim());
            item.SubItems.Add(reader["Year"].ToString().Trim());
            item.SubItems.Add(reader["Department"].ToString().Trim());


            return item;


        }

        private void Yaer_Department_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Yaer_Department.Text == "Year")
            {
                combo_box.Items.Clear();
                combo_box.Visible = true;
                combo_box.Items.Add("A");
                combo_box.Items.Add("B");
                combo_box.Items.Add("C");
                combo_box.Items.Add("D");
            }
            if (Yaer_Department.Text == "Department")
            {
                combo_box.Items.Clear();
                combo_box.Visible = true;
                combo_box.Items.Add("General");
                combo_box.Items.Add("Software");
                combo_box.Items.Add("Math");
            }

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void logOut_Click(object sender, EventArgs e)
        {
            Hide();
            login Main = new login();
            Main.Show();
        }

        private void ListCourses_Load(object sender, EventArgs e)
        {

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Hide();
            main ss = new main();
            ss.Show();
        }

       
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B_8
{
    public partial class NewUserRegistration : Form
    {
        string username,first, last, id, password, password_again, email, Role, department;
        DataBase db = new DataBase();
        SqlDataReader reader;

        private void Department_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void NewUserRegistration_Load(object sender, EventArgs e)
        {

        }

        private void EXIT_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            login ss = new login();
            ss.Show();
        }

        private void home_Click(object sender, EventArgs e)
        {
            this.Hide();
            main ss = new main();
            ss.Show();
        }

        private void role_SelectedIndexChanged(object sender, EventArgs e) { }

        

        public NewUserRegistration()
        {
            InitializeComponent();
        }

        private void confirm_Click(object sender, EventArgs e)
        {
            //
            try
            {
                first = textBox1.Text;
                last = textBox2.Text;
                username = first + last[0] + last[1];
                reader = db.Select("*", "UsersB", "UserName", username);
                int count = 0;
                while (reader.Read())
                {
                    if (reader["UserName"].ToString().Trim().Equals(username))
                        count++;
                }
                reader.Close();
                if (count > 0)
                    username += count.ToString();
                id = textBox3.Text;
                password = textBox4.Text;
                password_again = textBox5.Text;
                email = textBox6.Text;
                Role = role.Text;
                department = Department_comboBox.Text;

                if (email != "")
                {
                    if (password == password_again)
                    {
                        db.InsertUser(username, first, last, id, password, email, Role, department);
                        MessageBox.Show("The user name is: " + username);
                        this.Hide();
                        main ss = new main();
                        ss.Show();
                    }
                    else
                        MessageBox.Show("Wrong input!\n password not ...");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Could not connect to sql");
            }
            finally
            {
                if (db.isconnected == true)
                    db.CloseConnection();
            }

        }

        private void Department_Click(object sender, EventArgs e) { }
    }
}

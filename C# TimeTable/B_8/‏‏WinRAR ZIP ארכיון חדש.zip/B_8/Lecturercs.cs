﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_8
{
    class Lecturer
    {
        public string UserName;
        public string FirstName;
        public string LastName;
        public string ID;
        public string Password;
        public string Email;
        public string Role;
        public string Department;
        public string RemmemberMe;

        public Lecturer()
        { }
    }
}

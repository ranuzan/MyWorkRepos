﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B_8
{
    public partial class Contact_Us : Form
    {
        public bool IsUnitTest = false;

        public Contact_Us()
        {
            InitializeComponent();
            IsUnitTest = true;

            if (GlobalVariables.User_ID == null)
                home.Visible = false;
            else
                home.Visible = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e) { }

        private void home_Click(object sender, EventArgs e)
        {
            this.Hide();
            main ss = new main();
            ss.Show();
        }

        private void logOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            login ss = new login();
            ss.Show();
        }

        private void EXIT_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Contact_Us_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace B_8
{
    public partial class AddToSce : Form
    {
        DataBase db = new DataBase();
        public string hour, day, date;
        string[] Types = { "Practice", "Lecture", "Exam", "ReceptionHours", "Meeting" };
        Dictionary<ComboBox, string> last_pick = new Dictionary<ComboBox, string>();
        List<int> Serial_numbers;
        string temp_name, temp_ID, Class_name;
        Button B;
        static string[] Hours1 = { "08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00" };

        List<ListViewItem> List_Items = new List<ListViewItem>();
        List<ListViewGroup> List_Groups = new List<ListViewGroup>();
        List<string> Resposibles = new List<string>();
        List<ComboBox> comboboxes = new List<ComboBox>();
        Button btn;
        public Schedule parent;
        public Quat_date parent1;
        ListViewItem item;
        ListViewGroup group;
        DateTime ExamDate;
        public List<string> course_list_items;
        public AddToSce(Button b, string day, string hour, string date, Button btn, Schedule s = null, Quat_date c = null, string ClassName = null)
        {

            InitializeComponent();

            if (ClassName != null)
            {
                Class_name = ClassName;
            }
            this.hour = hour;
            this.day = day;
            parent = s;
            parent1 = c;
            button2.Enabled = false;

            this.date = date;
            Text = day + " , " + hour;
            CenterToScreen();
            B = b;
            this.btn = btn;
            Serial_numbers = new List<int>();
            course_list_items = new List<string>();

        }
        private bool calc_hours(string start, string end, string current_hour)
        {
            int s, e, Current;
            if (current_hour[0] == '0')
            {


                Current = current_hour[1] - 48;
            }
            else
            {
                Current = 10 * (current_hour[0] - 48) + (current_hour[1] - 48);
            }
            if (start[0] == '0')
            {
                s = start[1] - 48;
            }
            else
            {
                s = 10 * (start[0] - 48) + (start[1] - 48);
            }
            if (end[0] == '0')
            {
                e = end[1] - 48;
            }
            else
            {
                e = 10 * (end[0] - 48) + (end[1] - 48);
            }

            return Current >= s && Current < e;
        }
        private void AddToSce_Load(object sender, EventArgs e)
        {

            bool help = false;
            Start.Text = hour.Substring(0, 5);

            foreach (string item in Hours1)
            {

                if (Int32.Parse(item.Substring(0, 2)) > Int32.Parse(Start.Text.Substring(0, 2)))
                {
                    End.Items.Add(item);
                }
            }

            SqlDataReader reader3 = db.Select("*", "ScheduleB");
            while (reader3.Read())
            {
                help = true;
                string start, end;
                start = reader3["Hour"].ToString().Trim().Substring(0, 5);
                end = reader3["Hour"].ToString().Trim().Substring(6);
                if (day == reader3["Day"].ToString().Trim() && calc_hours(start, end, hour.Substring(0, 5)) && reader3["Semester"].ToString().Trim().Equals(GlobalVariables.Semester))
                {

                    if (reader3["Type"].ToString().Trim() == "Exam")
                    {

                        if (Check_exam_date(btn, reader3["Date"].ToString().Trim()))
                        {
                            group = new ListViewGroup(reader3["LecturerName"].ToString().Trim() + "-" + reader3["Type"].ToString().Trim() + "/" + reader3["NumOfExam"].ToString().Trim());
                            item = new ListViewItem(group);
                            item.Text = reader3["CourseName"].ToString().Trim() + " , " + reader3["Hour"].ToString().Trim();
                            Course_list.Groups.Add(group);
                            Course_list.Items.Add(item);
                            help = true;
                            group = null;
                            item = null;
                            continue;
                        }
                        help = false;

                    }

                    if (help)
                    {
                        group = new ListViewGroup(reader3["LecturerName"].ToString().Trim() + "-" + reader3["Type"].ToString().Trim());
                        Course_list.Groups.Add(group);
                        item = new ListViewItem(group);
                        item.Name = reader3["Class"].ToString().Trim();
                        item.Text = reader3["CourseName"].ToString().Trim() + " , " + reader3["Hour"].ToString().Trim();
                        Course_list.Items.Add(item);
                        group = null;
                        item = null;
                    }
                }
            }
            reader3.Close();

        }



        private bool Check_exam_date(Button btn, string ED)
        {
            string Sun_date = btn.Text.Substring(6 + 1);
            DateTime tempDate = new DateTime(Int32.Parse(Sun_date.Substring(6)), Int32.Parse(Sun_date.Substring(3, 2)), Int32.Parse(Sun_date.Substring(0, 2)));
            string Exam_date = ED;
            DateTime Week_from_now = tempDate.AddDays(6);
            ExamDate = new DateTime(Int32.Parse(Exam_date.Substring(6)), Int32.Parse(Exam_date.Substring(3, 2)), Int32.Parse(Exam_date.Substring(0, 2)));
            int diff = ExamDate.DayOfYear - tempDate.DayOfYear;
            int diff2 = ExamDate.DayOfYear - Week_from_now.DayOfYear;

            if (diff >= 0)
            {
                if (diff2 < 0)
                {
                    return true;
                }
            }
            return false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (End.Text != "Browse")
            {
                hour = Start.Text + "-" + End.Text;
                if (List_Items.Count >= 1)
                {
                    for (int i = 0; i < List_Items.Count; i++)
                    {
                        //if (i > 0)
                        //{
                        //    if (List_Groups[0].Header.Equals(List_Groups[0].Header))
                        //    {
                        //        MessageBox.Show(Lect.Text + " is already teaching in this day");
                        //        return;
                        //    }
                        //}
                        //   db.InsertSce(List_Groups[i].Header, hour, day, List_Items[i].Text, date,Type1.Text,Class.Text,Department.Text,Semester.Text,NumOfExam.Text);

                        //if (check_if_course_exist(Course_list.Items[i].Group.Header, hour, day, Course_list.Items[i].Text,date))
                        //      db.InsertSce(Course_list.Items[i].Group.Header, hour, day, Course_list.Items[i].Text,date);  
                    }

                }
                if (db.help == null)
                {
                    MessageBox.Show("Success!!");
                }
                B.Text = "...";
                this.Close();
                if (parent != null)
                {
                    parent.Close();
                }
                else if (parent1 != null)
                {
                    parent1 = null;
                }
                Schedule s2 = new Schedule();
                s2.Show();
            }
            else
            {
                MessageBox.Show("You haven't chose end hour");
            }
        }

        private bool check_if_course_exist(string LecturerName, string hour, string day, string Course_name, string date)
        {
            SqlDataReader reader4 = db.Select("*", "ScheduleB");
            while (reader4.Read())
            {
                if (LecturerName == reader4["LecturerName"].ToString().Trim())
                {
                    if (hour == reader4["Hour"].ToString().Trim())
                    {
                        if (day == reader4["Day"].ToString().Trim())
                        {
                            if (Course_name == reader4["CourseName"].ToString().Trim())
                            {
                                reader4.Close();
                                return false;
                            }
                        }
                    }
                }
            }
            reader4.Close();
            return true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            bool check = false;
            if (Course_list.Items.Count >= 1)
            {
                if (course_list_items.Count == 0)
                {
                    MessageBox.Show("This course is already in the current schedule");
                    return;
                }
                try
                {
                    DataBase db = new DataBase();
                    if (course_list_items[4].Equals("Exam"))
                    {
                        check = db.InsertSce(course_list_items[3], Start.Text + "-" + End.Text, day, course_list_items[2], date, course_list_items[4], course_list_items[6], course_list_items[1], course_list_items[0], course_list_items[7], course_list_items[5]);
                    }
                    else
                    {
                        check = db.InsertSce(course_list_items[3], Start.Text + "-" + End.Text, day, course_list_items[2], date, course_list_items[4], course_list_items[6], course_list_items[1], course_list_items[0]);
                    }
                    course_list_items.Clear();

                }
                catch (Exception)

                {
                    MessageBox.Show("Couldn't connect to sql server");
                }
                if (check)
                    MessageBox.Show("The course was successfully added");
                else
                {
                    MessageBox.Show("Error occurred");
                }
            }
            else
            {
                MessageBox.Show("Your list view is empty");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {



            if (Course_list.SelectedItems.Count == 1)
            {
                string c_name = Course_list.SelectedItems[0].Text.Split(new char[] { ',' })[0];
                SqlDataReader reader = db.Select("*", "ScheduleB");
                while (reader.Read())
                {
                    if (reader["CourseName"].ToString().Trim().Equals(c_name.Trim()))
                    {
                        if (reader["Class"].ToString().Trim().Equals(Course_list.SelectedItems[0].Name))
                        {

                            Serial_numbers.Add(Int32.Parse(reader["SerialNumber"].ToString().Trim()));

                        }
                    }
                }
                reader.Close();
                if (Serial_numbers.Count > 1)
                {

                    DeleteUserControl d = new DeleteUserControl(Serial_numbers, this);

                    foreach (Control c in this.Controls)
                    {
                        c.Visible = false;
                    }
                    this.Controls.Add(d);


                }
                else
                {
                    if (MessageBox.Show("Are you sure to delete?", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                    {
                        DataBase db2 = new DataBase();
                        SqlCommand cmd = new SqlCommand("DELETE FROM ScheduleB WHERE SerialNumber = @sn", db2.cnn);
                        cmd.Parameters.AddWithValue("@sn", Serial_numbers[0].ToString());
                        db2.Connect();
                        try
                        {
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Success");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error");
                        }
                    }

                    Course_list.Items.Remove(Course_list.SelectedItems[0]);
                }
            }
        }


        private bool calc_hours(string start, string end)
        {
            int s, e, Hour;
            if (start[0] == '0')
            {
                s = start[1] - 48;
            }
            else
            {
                s = 10 * (start[0] - 48) + (start[1] - 48);
            }
            if (end[0] == '0')
            {
                e = end[1] - 48;
            }
            else
            {
                e = 10 * (end[0] - 48) + (end[1] - 48);
            }
            if (hour[0] == '0')
            {
                Hour = hour[1] - 48;
            }
            else
            {
                Hour = 10 * (hour[0] - 48) + (hour[1] - 48);
            }
            if (s <= Hour && e >= Hour)
            {
                return false;
            }
            return true;
        }










        private void Start_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Course_list_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.End.Text != "Browse")
            {
                button2.Enabled = true;
                Add_Deatils f = new B_8.Add_Deatils(this);
                f.Show();
            }
            else
            {
                MessageBox.Show("You haven't chose end hour");
            }


        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void End_SelectedIndexChanged(object sender, EventArgs e)
        {
            button2.Enabled = true;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        public void changeClass(string ClassName)
        {
        }
        public bool check_if_exist(string name)
        {
            if (this.Course_list.Groups.Count >= 1)
            {
                for (int i = 0; i < this.Course_list.Groups.Count; i++)
                {
                    if ((this.Course_list.Groups[i].Header.Equals(name + "-" + "Lecture")) || (this.Course_list.Groups[i].Header.Equals(name + "-" + "Exam")) || (this.Course_list.Groups[i].Header.Equals(name + "-" + "ReceptionHours")) || (this.Course_list.Groups[i].Header.Equals(name + "-" + "Practice")) || (this.Course_list.Groups[i].Header.Equals(name)))
                    {

                        return false;
                    }

                }
            }
            return true;
        }
        public string getClass()
        {
            if (Class_name != null)
            {
                return Class_name;
            }
            return "null";
        }
    }

}

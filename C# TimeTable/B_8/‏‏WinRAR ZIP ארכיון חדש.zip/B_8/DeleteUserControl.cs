﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B_8
{
    public partial class DeleteUserControl : UserControl
    {
        List<int> SN;
        DataBase db;
        SqlDataReader reader;
        AddToSce parent;
        public DeleteUserControl(List <int> SN,AddToSce s)
        {
            InitializeComponent();
            this.SN = SN;
            db = new DataBase();
            parent = s;
        
        }

        private void DeleteUserControl_Load(object sender, EventArgs e)
        {
            try
            {
                reader = db.Select("*", "ScheduleB");
                while (reader.Read())
                {
                    foreach (int temp in SN)
                    {
                        if (temp.ToString() == reader["SerialNumber"].ToString().Trim())
                        {
                            ListViewItem item = new ListViewItem(reader["CourseName"].ToString().Trim());
                            item.Name = temp.ToString();
                            item.SubItems.Add(reader["LecturerName"].ToString().Trim());
                            item.SubItems.Add(reader["Hour"].ToString().Trim());
                            item.SubItems.Add(reader["Day"].ToString().Trim());
                            item.SubItems.Add(reader["Type"].ToString().Trim());
                            item.SubItems.Add(reader["Class"].ToString().Trim());
                            listView1.Items.Add(item);
                        }
                    }
                }
            }
            catch(Exception exp)
            {
                MessageBox.Show("Colud not connect to sql");

            }
            finally
            {
                if (db.isconnected == true)
                    db.CloseConnection();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DataBase db2 = new DataBase();
                if (listView1.SelectedItems.Count > 0)
                {
                    if (MessageBox.Show("Are you sure to delete?", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                    {
                        db2.DeleteBySN("ScheduleB", "SerialNumber", listView1.SelectedItems[0].Name);

                        if (db.help == null)
                        {
                            MessageBox.Show("Success");
                        }
                        else
                            MessageBox.Show("Error");
                        parent.parent.Close();
                        parent.Close();
                        Schedule s = new Schedule();
                        s.Show();
                    }
                }
            }
            catch(Exception exp)
            {
                MessageBox.Show("Colud not connect to sql");

            }
            finally
            {
                if (db.isconnected == true)
                    db.CloseConnection();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            parent.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

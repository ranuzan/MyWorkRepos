﻿namespace B_8
{
    partial class ListCourses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.combo_box = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Yaer_Department = new System.Windows.Forms.ComboBox();
            this.logOut = new System.Windows.Forms.PictureBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Credits = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LectureHour = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Semster = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Year = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logOut)).BeginInit();
            this.SuspendLayout();
            // 
            // combo_box
            // 
            this.combo_box.Cursor = System.Windows.Forms.Cursors.Hand;
            this.combo_box.FormattingEnabled = true;
            this.combo_box.Location = new System.Drawing.Point(279, 14);
            this.combo_box.Name = "combo_box";
            this.combo_box.Size = new System.Drawing.Size(121, 21);
            this.combo_box.TabIndex = 0;
            this.combo_box.SelectedIndexChanged += new System.EventHandler(this.Year_C_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Filter";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::B_8.Properties.Resources.home_button;
            this.pictureBox1.Location = new System.Drawing.Point(3, 360);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(192, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, "Return to menu");
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Yaer_Department
            // 
            this.Yaer_Department.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Yaer_Department.Items.AddRange(new object[] {
            "Year",
            "Department"});
            this.Yaer_Department.Location = new System.Drawing.Point(119, 14);
            this.Yaer_Department.Name = "Yaer_Department";
            this.Yaer_Department.Size = new System.Drawing.Size(121, 21);
            this.Yaer_Department.TabIndex = 6;
            this.toolTip1.SetToolTip(this.Yaer_Department, "Choose option");
            this.Yaer_Department.SelectedIndexChanged += new System.EventHandler(this.Yaer_Department_SelectedIndexChanged);
            // 
            // logOut
            // 
            this.logOut.Image = global::B_8.Properties.Resources.logout_button;
            this.logOut.Location = new System.Drawing.Point(516, 346);
            this.logOut.Name = "logOut";
            this.logOut.Size = new System.Drawing.Size(109, 91);
            this.logOut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logOut.TabIndex = 4;
            this.logOut.TabStop = false;
            this.logOut.Click += new System.EventHandler(this.logOut_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.ID,
            this.Credits,
            this.LectureHour,
            this.columnHeader2,
            this.columnHeader3,
            this.Semster,
            this.Year,
            this.columnHeader6});
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(38, 71);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(587, 188);
            this.listView1.TabIndex = 11;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            // 
            // ID
            // 
            this.ID.Text = "ID";
            // 
            // Credits
            // 
            this.Credits.Text = "Credits";
            // 
            // LectureHour
            // 
            this.LectureHour.Text = "LectureHour";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Practic Hour";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "reciept Hour";
            // 
            // Semster
            // 
            this.Semster.Text = "Semster";
            // 
            // Year
            // 
            this.Year.Text = "Year";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Department";
            this.columnHeader6.Width = 94;
            // 
            // ListCourses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::B_8.Properties.Resources.background_faq;
            this.ClientSize = new System.Drawing.Size(637, 449);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.Yaer_Department);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.logOut);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.combo_box);
            this.Name = "ListCourses";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ListCourses";
            this.Load += new System.EventHandler(this.ListCourses_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logOut)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combo_box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox logOut;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ComboBox Yaer_Department;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader Credits;
        private System.Windows.Forms.ColumnHeader LectureHour;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader Year;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader Semster;
    }
}
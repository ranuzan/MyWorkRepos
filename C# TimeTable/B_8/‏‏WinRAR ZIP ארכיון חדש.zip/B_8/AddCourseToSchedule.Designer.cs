﻿namespace B_8
{
    partial class AddCourseToSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Course = new System.Windows.Forms.ComboBox();
            this.listView = new System.Windows.Forms.ListView();
            this.Credits = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LectureHour = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.PracticeHour = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.receiptHour = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Semester = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Year = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.confirm = new System.Windows.Forms.PictureBox();
            this.home = new System.Windows.Forms.PictureBox();
            this.logOut = new System.Windows.Forms.PictureBox();
            this.EXIT = new System.Windows.Forms.PictureBox();
            this.Day_Lecture = new System.Windows.Forms.ComboBox();
            this.StartTime = new System.Windows.Forms.ComboBox();
            this.EndTime = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.confirm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.home)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logOut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Niagara Engraved", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(254, 24);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 51);
            this.label1.TabIndex = 58;
            this.label1.Text = "Filter";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Course
            // 
            this.Course.FormattingEnabled = true;
            this.Course.Location = new System.Drawing.Point(375, 48);
            this.Course.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Course.Name = "Course";
            this.Course.Size = new System.Drawing.Size(180, 28);
            this.Course.TabIndex = 59;
            this.Course.Text = "Course";
            this.Course.SelectedIndexChanged += new System.EventHandler(this.Course_SelectedIndexChanged);
            // 
            // listView
            // 
            this.listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Credits,
            this.LectureHour,
            this.PracticeHour,
            this.receiptHour,
            this.Semester,
            this.Year});
            this.listView.Cursor = System.Windows.Forms.Cursors.Default;
            this.listView.GridLines = true;
            this.listView.Location = new System.Drawing.Point(26, 191);
            this.listView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listView.Name = "listView";
            this.listView.Size = new System.Drawing.Size(784, 89);
            this.listView.TabIndex = 62;
            this.listView.UseCompatibleStateImageBehavior = false;
            this.listView.View = System.Windows.Forms.View.Details;
            this.listView.SelectedIndexChanged += new System.EventHandler(this.listView_SelectedIndexChanged);
            // 
            // Credits
            // 
            this.Credits.Tag = "1";
            this.Credits.Text = "Credits";
            this.Credits.Width = 97;
            // 
            // LectureHour
            // 
            this.LectureHour.Text = "Lecture Hour";
            this.LectureHour.Width = 97;
            // 
            // PracticeHour
            // 
            this.PracticeHour.Text = "Practice Hour";
            this.PracticeHour.Width = 93;
            // 
            // receiptHour
            // 
            this.receiptHour.Text = "receipt Hour";
            this.receiptHour.Width = 90;
            // 
            // Semester
            // 
            this.Semester.Text = "Semester";
            this.Semester.Width = 77;
            // 
            // Year
            // 
            this.Year.Text = "Year";
            this.Year.Width = 55;
            // 
            // confirm
            // 
            this.confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.confirm.Image = global::B_8.Properties.Resources.confirm;
            this.confirm.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.confirm.Location = new System.Drawing.Point(298, 579);
            this.confirm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.confirm.Name = "confirm";
            this.confirm.Size = new System.Drawing.Size(189, 98);
            this.confirm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.confirm.TabIndex = 56;
            this.confirm.TabStop = false;
            this.confirm.Click += new System.EventHandler(this.confirm_Click);
            // 
            // home
            // 
            this.home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.home.Image = global::B_8.Properties.Resources.home_button;
            this.home.Location = new System.Drawing.Point(15, 24);
            this.home.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.home.Name = "home";
            this.home.Size = new System.Drawing.Size(191, 70);
            this.home.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.home.TabIndex = 51;
            this.home.TabStop = false;
            this.home.Click += new System.EventHandler(this.home_Click);
            // 
            // logOut
            // 
            this.logOut.Image = global::B_8.Properties.Resources.logout_button;
            this.logOut.Location = new System.Drawing.Point(706, 31);
            this.logOut.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.logOut.Name = "logOut";
            this.logOut.Size = new System.Drawing.Size(159, 62);
            this.logOut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logOut.TabIndex = 50;
            this.logOut.TabStop = false;
            this.logOut.Click += new System.EventHandler(this.logOut_Click);
            // 
            // EXIT
            // 
            this.EXIT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EXIT.Image = global::B_8.Properties.Resources.exit;
            this.EXIT.Location = new System.Drawing.Point(719, 606);
            this.EXIT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EXIT.Name = "EXIT";
            this.EXIT.Size = new System.Drawing.Size(147, 70);
            this.EXIT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.EXIT.TabIndex = 49;
            this.EXIT.TabStop = false;
            this.EXIT.Click += new System.EventHandler(this.EXIT_Click_1);
            // 
            // Day_Lecture
            // 
            this.Day_Lecture.Font = new System.Drawing.Font("David", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Day_Lecture.FormattingEnabled = true;
            this.Day_Lecture.Items.AddRange(new object[] {
            "Sunday",
            "Monday",
            "Tuseday",
            "Wednesday",
            "Thursday",
            "Friday"});
            this.Day_Lecture.Location = new System.Drawing.Point(298, 329);
            this.Day_Lecture.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Day_Lecture.Name = "Day_Lecture";
            this.Day_Lecture.Size = new System.Drawing.Size(186, 40);
            this.Day_Lecture.TabIndex = 65;
            this.Day_Lecture.Text = "Day Lecture";
            // 
            // StartTime
            // 
            this.StartTime.Font = new System.Drawing.Font("David", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.StartTime.FormattingEnabled = true;
            this.StartTime.Items.AddRange(new object[] {
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00"});
            this.StartTime.Location = new System.Drawing.Point(298, 399);
            this.StartTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.StartTime.Name = "StartTime";
            this.StartTime.Size = new System.Drawing.Size(186, 40);
            this.StartTime.TabIndex = 66;
            this.StartTime.Text = "Start Time";
            // 
            // EndTime
            // 
            this.EndTime.Font = new System.Drawing.Font("David", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.EndTime.FormattingEnabled = true;
            this.EndTime.Items.AddRange(new object[] {
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.EndTime.Location = new System.Drawing.Point(298, 464);
            this.EndTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EndTime.Name = "EndTime";
            this.EndTime.Size = new System.Drawing.Size(186, 40);
            this.EndTime.TabIndex = 67;
            this.EndTime.Text = "End Time";
            // 
            // AddCourseToSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 691);
            this.Controls.Add(this.EndTime);
            this.Controls.Add(this.StartTime);
            this.Controls.Add(this.Day_Lecture);
            this.Controls.Add(this.listView);
            this.Controls.Add(this.Course);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.confirm);
            this.Controls.Add(this.home);
            this.Controls.Add(this.logOut);
            this.Controls.Add(this.EXIT);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "AddCourseToSchedule";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddCourseToSchedule";
            this.Load += new System.EventHandler(this.AddCourseToSchedule_Load);
            ((System.ComponentModel.ISupportInitialize)(this.confirm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.home)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logOut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EXIT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox home;
        private System.Windows.Forms.PictureBox logOut;
        private System.Windows.Forms.PictureBox EXIT;
        private System.Windows.Forms.PictureBox confirm;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox Course;
        private System.Windows.Forms.ListView listView;
        public System.Windows.Forms.ColumnHeader Credits;
        private System.Windows.Forms.ColumnHeader LectureHour;
        private System.Windows.Forms.ColumnHeader receiptHour;
        private System.Windows.Forms.ColumnHeader Semester;
        private System.Windows.Forms.ColumnHeader Year;
        private System.Windows.Forms.ColumnHeader PracticeHour;
        private System.Windows.Forms.ComboBox Day_Lecture;
        private System.Windows.Forms.ComboBox StartTime;
        private System.Windows.Forms.ComboBox EndTime;
    }
}
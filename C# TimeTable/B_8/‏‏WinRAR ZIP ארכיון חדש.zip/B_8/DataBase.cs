﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_8
{
    public class DataBase
    {
        public SqlConnection cnn;
        public bool isconnected = false;
        public string help;
        public static int numofcourses = 0;
        public bool IsUnitTest = false;

        public DataBase()
        {
            string connetionString = "Data Source=team8db.database.windows.net;Initial Catalog=Team8DB;Persist Security Info=True;User ID=dbadmin;Password=Aa123456";
            cnn = new SqlConnection(connetionString);
            isconnected = false;
            help = null;
            IsUnitTest = true;
        }

        public bool Connect()
        {
            if (!isconnected)
            {
                try
                {
                    cnn.Open();
                    isconnected = true;
                    help = null;
                }
                catch (Exception )
                {
                    help = "Could not connect!";
                }
            }
            else
            {
                try
                {
                    cnn.Close();
                    isconnected = false;
                    help = null;
                }
                catch (Exception )
                {
                    help = "Could not disconnect!";
                }
            }
            return true;
        }

        public bool DeleteBySN(string table,string where,string param)
        {
            try
            {
                if (isconnected == false)
                {
                    Connect();
                }
                SqlCommand cmd = new SqlCommand("DELETE FROM dbo.ScheduleB WHERE SerialNumber=@sn", cnn);
                cmd.Parameters.AddWithValue("@sn", Int32.Parse(param));


                cmd.ExecuteNonQuery();
                help = null;

            }
            catch (Exception ex)
            {
                help = "Error";

            }
            return true;
        }

        public SqlDataReader Select(string msg, string table)
        {
            if (isconnected == false)
            {
                Connect();
            }
            SqlCommand cmd = new SqlCommand("select " + msg + " from " + table, cnn);
            SqlDataReader read = cmd.ExecuteReader();
            return read;
        }

        public SqlDataReader Select(string msg, string table, string where, string what)
        {
            if (!isconnected)
            {
                Connect();
            }
            try
            {
                
                SqlCommand cmd = new SqlCommand("select " + msg + " from " + table + " where " + where + " = @what", cnn);
                cmd.Parameters.AddWithValue("@what", what.ToString());
                SqlDataReader read = cmd.ExecuteReader();
                cmd.Dispose();
                return read;
            }
            catch (Exception)
            {

                return null;
            }
        
        }

        public void CloseConnection()
        {
            try
            {
                cnn.Close();
                isconnected = false;
            }
            catch (Exception)
            {

                isconnected = false;
            }
        }
        public void OpenConnection()
        {
            try
            {
                cnn.Open();
                isconnected = true;
            }
            catch (Exception)
            {

                isconnected = true;
            }
        }

        public bool Update(string param, string table, string columname, string SerialNumber)
        {
            if (!isconnected)
            {
                Connect();
            }
            SqlCommand cmd = new SqlCommand("update " + table + " SET " + columname + " =@param where SerialNumber=@SerialNumber",cnn);
            cmd.Parameters.AddWithValue("@param", param);
            cmd.Parameters.Add("@SerialNumber", SqlDbType.Int);
            cmd.Parameters["@SerialNumber"].Value = Int32.Parse(SerialNumber);
            cmd.ExecuteNonQuery();

            return true;
        }

        public bool InsertUser(string username,string first, string last, string id, string pass, string email, string role,string department)
        {
            if (!isconnected)
            {
                Connect();
            }
            SqlCommand cmd = new SqlCommand("INSERT INTO UsersB(UserName,FirstName,LastName,ID,Password,Email,Role,Department) VALUES(@username,@first,@last,@id,@pass,@email,@role,@department)", cnn);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@first", first);
            cmd.Parameters.AddWithValue("@last", last);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@pass", pass);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@role", role);
            cmd.Parameters.AddWithValue("@department", department);

            try
            {
                cmd.ExecuteNonQuery();
                help = null;
            }
            catch (Exception)
            {
                help = "Could not debug SQL COMMAND! -> InsertUser";
            }
            return true;
        }

        public bool InsertCourse(string name, string id, string credits, string lectureH, string practiceH, string receiptH, string semster, string year, string department)
        {
            if (!isconnected)
            {
                Connect();
            }
            SqlCommand cmd = new SqlCommand("INSERT INTO Courses(Name,ID,Credits,LectureHour,PracticeHour,ReceptionHour,Semester,Year,Department) VALUES(@name, @id,@credits,@lectureH,@practiceH,@receiptH,@semester,@year,@department)", cnn);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@credits", credits);
            cmd.Parameters.AddWithValue("@lectureH", lectureH);
            cmd.Parameters.AddWithValue("@practiceH", practiceH);
            cmd.Parameters.AddWithValue("@receiptH", receiptH);
            cmd.Parameters.AddWithValue("@Semester", semster);
            cmd.Parameters.AddWithValue("@year", year);
            cmd.Parameters.AddWithValue("@department", department);



            try
            {
                cmd.ExecuteNonQuery();
                help = null;
            }
            catch (Exception)
            {
                help = "Could not debug SQL COMMAND! -> InsertCourse";
            }
            return true;
        }

        
        public bool InsertSce(string nameLact,string hour,string day ,string courseName,string date,string type,string Class,string dep,string sem,string numOfExam="NULL",string Responssibles="NULL")
        {
            if (!isconnected)
            {
                Connect();
            }


            SqlCommand cmd2 = new SqlCommand("INSERT INTO ScheduleB (CourseName,LecturerName,Hour,Day,Date,Type,Class,Department,Semester,Seen,Canceled,NumOfExam,Responsible) VALUES(@courseName,@nameLact,@hour,@day,@date,@type,@Class,@dep,@sem,@Seen,@Canceled,@numOfExam,@responsible)", cnn);
            cmd2.Parameters.AddWithValue("@courseName", courseName);
            cmd2.Parameters.AddWithValue("@nameLact", nameLact);
            cmd2.Parameters.AddWithValue("@hour", hour);
            cmd2.Parameters.AddWithValue("@day", day);
            cmd2.Parameters.AddWithValue("@date", date);
            cmd2.Parameters.AddWithValue("@type", type);
            cmd2.Parameters.AddWithValue("@Class", Class);            
            cmd2.Parameters.AddWithValue("@dep", dep);
            cmd2.Parameters.AddWithValue("@sem", sem);
            cmd2.Parameters.AddWithValue("@Seen", "False");
            cmd2.Parameters.AddWithValue("@Canceled", "False");
            cmd2.Parameters.AddWithValue("@numOfExam", numOfExam);
            cmd2.Parameters.AddWithValue("@responsible", Responssibles);



            try
            {
                cmd2.ExecuteNonQuery();
                help = null;
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
                help = "Could not debug SQL COMMAND! -> InsertSce";
                return false;
            }
            return true;
        }

        public bool InsertContstraints(string User_ID, string Days, string StartHours, string EndHours, string Notes, string Date, string Semester, string Course)
        {
            if (!isconnected)
            {
                Connect();
            }
            string FullName = GlobalVariables.Full_Name;
            string Seen = "false";
            string Approved = "false";
            SqlCommand cmd = new SqlCommand("INSERT INTO Constraints(User_ID, Days,  StartHours,  EndHours,  Notes,FullName,Seen,Date,Semester,Approved,Course) VALUES(@User_ID,  @Days,  @StartHours,  @EndHours,  @Notes,@FullName,@Seen,@Date,@Semester,@Approved,@Course)", cnn);
            cmd.Parameters.AddWithValue("@User_ID", User_ID);
            cmd.Parameters.AddWithValue("@Days", Days);
            cmd.Parameters.AddWithValue("@StartHours", StartHours);
            cmd.Parameters.AddWithValue("@EndHours", EndHours);
            cmd.Parameters.AddWithValue("@Notes", Notes);
            cmd.Parameters.AddWithValue("@FullName", FullName);
            cmd.Parameters.AddWithValue("@Seen", Seen);
            cmd.Parameters.AddWithValue("@Date", Date);
            cmd.Parameters.AddWithValue("@Semester", Semester);
            cmd.Parameters.AddWithValue("@Approved", Approved);
            cmd.Parameters.AddWithValue("@Course", Course);
            try
            {
                cmd.ExecuteNonQuery();
                help = null;
            }
            catch (Exception)
            {
                help = "Could not debug SQL COMMAND! -> InsertCourseToSchedule";
            }

            return true;
        } 
    }
}

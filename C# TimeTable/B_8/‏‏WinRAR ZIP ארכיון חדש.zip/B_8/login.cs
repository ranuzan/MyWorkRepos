﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication6;

namespace B_8
{
    public partial class login : Form
    {
        DataBase db = new DataBase();
        bool IsFound;
        string ID;
        public bool IsUnitTest = false;





        public login()
        {
            InitializeComponent();
            IsFound = false;
            /*   Reset User fields   */
            GlobalVariables.User_ID = null;
            GlobalVariables.Full_Name = null;
            GlobalVariables.User_Permission = null;
            GlobalVariables.User_Department = null;
            GlobalVariables.User_Name = null;
            GlobalVariables.User_Email = null;
            IsUnitTest = true;
        }

        private void confirm_Click(object sender, EventArgs e)
        {

            
        }
        

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ForgetPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            ForgotMyPassword ss = new ForgotMyPassword();
            ss.Show();
        }

        private void label2_Click(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {

                SqlDataReader read = db.Select("*", "UsersB");
                while (read.Read())
                {
                    if (read["RemmemberMe"].ToString().Trim() == "True" && read["UserName"].ToString().Trim().Equals(textBox1.Text))
                    {
                        textBox2.Text = read["Password"].ToString().Trim();
                        checkBox1.Checked = true;
                    }
                }
                read.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Could not connect to sql");
            }
            finally
            {
                if (db.isconnected == true)
                    db.CloseConnection();
            }
        }

        private void input_KeyDown(object sender, KeyEventArgs e)
        {

           /* if (e.KeyCode == Keys.Enter)
            {
                confirm_Click( sender, new EventArgs());
            }*/
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FAQ ss = FAQ.GetInstance();
            
            ss.Show();
        }

        private void login_Load(object sender, EventArgs e)
        {
            try
            {
                SqlDataReader read = db.Select("*", "UsersB");
                while (read.Read())
                {
                    textBox1.AutoCompleteCustomSource.Add(read["UserName"].ToString().Trim());
                }
                read.Close();
            }
            catch(Exception exception)
            {
                MessageBox.Show("Error: reading from sql");
            }
            finally
            {
                if (db.isconnected == true)
                    db.CloseConnection();
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime end_of_exams_semester_a = new DateTime(DateTime.Today.Year, 3, 5);
            DateTime end_of_semester_b = new DateTime(DateTime.Today.Year, 6, 15);
            DateTime end_of_exams_semester_b = new DateTime(DateTime.Today.Year, 7, 15);
            SqlDataReader read = db.Select("*", "UsersB");
            try
            {
                while (read.Read())
                {

                    if (textBox1.Text == read["UserName"].ToString().Trim() && textBox2.Text == read["Password"].ToString().Trim())
                    {

                        ID = read["ID"].ToString();
                        // GlobalVariables h;.ID = read["ID"].ToString().Trim();
                        GlobalVariables.User_ID = read["ID"].ToString().Trim();
                        GlobalVariables.Full_Name = read["FirstName"].ToString().Trim() + " " + read["LastName"].ToString().Trim();
                        GlobalVariables.User_Permission = read["Role"].ToString().Trim();
                        GlobalVariables.User_Department = read["Department"].ToString().Trim();
                        GlobalVariables.User_Name = read["UserName"].ToString().Trim();
                        GlobalVariables.User_Email = read["Email"].ToString().Trim();
                        if (monthCalendar1.MaxDate >= DateTime.Today && monthCalendar1.MinDate <= DateTime.Today)
                            GlobalVariables.Semester = "A";
                        else if (monthCalendar1.MaxDate < DateTime.Today && DateTime.Today <= end_of_exams_semester_a)
                            GlobalVariables.Semester = "Exam Period semester A";
                        else if (end_of_exams_semester_a < DateTime.Today && DateTime.Today <= end_of_semester_b)
                            GlobalVariables.Semester = "B";
                        else if (end_of_exams_semester_b >= DateTime.Today && DateTime.Today > end_of_semester_b)
                            GlobalVariables.Semester = "Exam Period semester B";
                        else
                            GlobalVariables.Semester = "Summer Semester";
                        IsFound = true;
                    }

                    GlobalVariables.maxDate = monthCalendar1.MaxDate;
                    GlobalVariables.minDate = monthCalendar1.MinDate;
                }
                read.Close();
                if (checkBox1.Checked)
                {
                    if (!db.isconnected)
                        db.Connect();
                    SqlCommand cmd = new SqlCommand("UPDATE UsersB SET RemmemberMe=@parm WHERE ID=" + ID, db.cnn);
                    cmd.Parameters.AddWithValue("@parm", "True");
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    if (!db.isconnected)
                        db.Connect();
                    SqlCommand cmd = new SqlCommand("UPDATE UsersB SET RemmemberMe=@parm WHERE ID=" + ID, db.cnn);
                    cmd.Parameters.AddWithValue("@parm", "False");
                    cmd.ExecuteNonQuery();
                }
                this.Hide();
                //SplashScreen s = new SplashScreen();
                //s.Show();
                main m = new main();
                m.Show();
               
                if (!IsFound)
                    MessageBox.Show("You have to sign up before");
            }
            catch
            {
                MessageBox.Show("ERROR");

            }
            finally
            {
                if (db.isconnected == true)
                    db.CloseConnection();
            }
        }
        
    }
}
